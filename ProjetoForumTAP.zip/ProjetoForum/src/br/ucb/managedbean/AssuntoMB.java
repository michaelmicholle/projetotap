package br.ucb.managedbean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.ucb.entidade.Assunto;
import br.ucb.util.JPAUtil;

@ManagedBean
@RequestScoped
public class AssuntoMB {
	
	private Assunto assunto =new Assunto();
	private List<Assunto> assuntos=null;
	
	public String salvar(Assunto assunto){
		EntityManager manager = JPAUtil.getEntityManager();
		manager.getTransaction().begin();
		manager.persist(assunto);
		manager.getTransaction().commit();
		manager.close();
		return("index");
	}
	public List<Assunto> getAssuntos() {
		if(this.assuntos == null){
		EntityManager manager = JPAUtil.getEntityManager();
		Query query = manager.createQuery("select e from Assunto e", Assunto.class);
		this.assuntos = query.getResultList();
		}
		return assuntos;
	}
	public Assunto getAssunto() {
		return assunto;
	}

	public void setAssunto(Assunto assunto) {
		this.assunto = assunto;
	}
	

}
