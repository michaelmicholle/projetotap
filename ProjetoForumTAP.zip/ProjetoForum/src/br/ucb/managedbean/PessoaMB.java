package br.ucb.managedbean;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.ucb.entidade.Pessoa;
import br.ucb.util.JPAUtil;

@ManagedBean
@ApplicationScoped
public class PessoaMB {

	private Pessoa pessoa= new Pessoa();
	private List<Pessoa> pessoas=null;
	
	public String redirecionar(){
		return("cadastroUsu�rio");
	}
	
	
	public String salvar(Pessoa pessoa){
		EntityManager manager = JPAUtil.getEntityManager();
		manager.getTransaction().begin();
		manager.persist(pessoa);
		manager.getTransaction().commit();
		manager.close();
		
		FacesMessage facesMessage = new FacesMessage ("Usu�rio cadastrado com sucesso");
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);
		return("index");
	}
	
	public void remover(){
		
		EntityManager manager = JPAUtil.getEntityManager();
		manager.getTransaction().begin();
		manager.remove(manager.merge(pessoa));
		manager.getTransaction().commit();
		manager.close();
	}

	public List<Pessoa> getPessoas() {
		if(this.pessoas == null){
		EntityManager manager = JPAUtil.getEntityManager();
		Query query = manager.createQuery("select e from Pessoa e", Pessoa.class);
		this.pessoas = query.getResultList();
		}
		return pessoas;
	}

	public void setPessoas(List<Pessoa> pessoas) {
		this.pessoas = pessoas;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	
	
}
