package br.ucb.managedbean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.ucb.entidade.Forum;
import br.ucb.util.JPAUtil;

@ManagedBean
@RequestScoped
public class ForumMB {
	
	private Forum forum = new Forum();
	private List<Forum> forums=null;
	
	public String salvar(Forum forum){
		EntityManager manager = JPAUtil.getEntityManager();
		manager.getTransaction().begin();
		manager.persist(forum);
		manager.getTransaction().commit();
		manager.close();
		return("index");
	}
	
	public List<Forum> getForums() {
		if(this.forums == null){
		EntityManager manager = JPAUtil.getEntityManager();
		Query query = manager.createQuery("select e from Forum e", Forum.class);
		this.forums = query.getResultList();
		}
		return forums;
	}
	public Forum getForum() {
		return forum;
	}

	public void setForum(Forum forum) {
		this.forum = forum;
	}

}
